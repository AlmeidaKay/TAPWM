var nomeAluno = prompt("Digite seu nome:")
var nota1 =  prompt("Digite sua primeira nota:")
var nota2 =  prompt("Digite sua segunda nota:")
var nota3 =  prompt("Digite sua terceira nota:")
var mediaAluno = parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)/3

alert("A media do(a) aluno(a) " + nomeAluno + " é " + mediaAluno)