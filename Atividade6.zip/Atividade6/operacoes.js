var num1 = prompt("Digite o primeiro numero")
var num2 = prompt("Digite o segundo numero")

var soma = parseFloat(num1) + parseFloat(num2);
var subtracao = parseFloat(num1) - parseFloat(num2);
var produto = parseFloat(num1) * parseFloat(num2);
var divisao = parseFloat(num1) / parseFloat(num2);
var restoDivisao = parseFloat(num1) % parseFloat(num2);

alert("A soma dos numeros é: " + soma + "\nA subtração dos numeros é: " + 
subtracao + "\nO produto dos numeros é: " + produto + "\nA divisao dos numeros é: " + 
divisao + "\nO resto da divisão é: " + restoDivisao);