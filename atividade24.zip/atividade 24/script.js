function dividir() {
    let a = parseFloat(prompt("Digite o primeiro número:"));
    let b = parseFloat(prompt("Digite o segundo número:"));
  
    let resultado = a / b;
  
    if (isNaN(resultado)) {
      console.log("Divisão deu NaN");
    } else if (!isFinite(resultado)) {
        console.log("Divisão de Infinity");
    } else {
        console.log("Resultado da divisão: " + resultado);
    }
  }
  
  dividir();