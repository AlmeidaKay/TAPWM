var totalIdade = 0;
var idadeMaisVelha = 0;
var idadeMaisNova = Infinity;
var totalPessimo = 0;
var totalOtimoBom = 0;
var totalMulheres = 0;
var totalHomens = 0;

// Simulação
var dados = [
    { idade: 30, sexo: 'mulher', opiniao: 'bom' },
    { idade: 25, sexo: 'homem', opiniao: 'ótimo' },
    { idade: 40, sexo: 'homem', opiniao: 'regular' },
    { idade: 50, sexo: 'mulher', opiniao: 'péssimo' },
    { idade: 60, sexo: 'mulher', opiniao: 'bom' },
    { idade: 47, sexo: 'homem', opiniao: 'ótimo' },
    { idade: 23, sexo: 'homem', opiniao: 'ótimo' },
    { idade: 68, sexo: 'homem', opiniao: 'ótimo' },

];


for (var i = 0; i < dados.length; i++) {
    var pessoa = dados[i];

    totalIdade += pessoa.idade;

    if (pessoa.idade > idadeMaisVelha) {
        idadeMaisVelha = pessoa.idade;
    }

    if (pessoa.idade < idadeMaisNova) {
        idadeMaisNova = pessoa.idade;
    }

    if (pessoa.opiniao === 'péssimo') {
        totalPessimo++;
    }

    if (pessoa.opiniao === 'ótimo' || pessoa.opiniao === 'bom') {
        totalOtimoBom++;
    }

    if (pessoa.sexo === 'mulher') {
        totalMulheres++;
    } else if (pessoa.sexo === 'homem') {
        totalHomens++;
    }
}


var mediaIdade = totalIdade / dados.length;

var porcentagemOtimoBom = (totalOtimoBom / dados.length) * 100;

alert('Média da idade: ' + mediaIdade);
alert('Idade da pessoa mais velha: ' + idadeMaisVelha);
alert('Idade da pessoa mais nova: ' + idadeMaisNova);
alert('Quantidade de pessoas que responderam péssimo: ' + totalPessimo);
alert('Porcentagem de pessoas que responderam ótimo e bom: ' + porcentagemOtimoBom.toFixed(2) + '%');
alert('Número de mulheres que responderam a pesquisa: ' + totalMulheres);
alert('Número de homens que responderam a pesquisa: ' + totalHomens);
