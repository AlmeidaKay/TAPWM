var A = parseFloat(prompt("Digite um valor para A:"));
var B = parseFloat(prompt("Digite um valor para B:"));
var C = parseFloat(prompt("Digite um valor para C:"));


if (isNaN(A) || isNaN(B) || isNaN(C)) {
  alert("Insira números válidos.");
} else {
  
  if (A < B + C && B < A + C && C < A + B) {
    
    if (A === B && B === C) {
      alert("O triângulo formado é equilátero.");
    } else if (A === B || A === C || B === C) {
      alert("O triângulo formado é isósceles.");
    } else {
      alert("O triângulo formado é escaleno.");
    }
  } else {
    alert("Esses valores não podem formar um triângulo.");
  }
}
